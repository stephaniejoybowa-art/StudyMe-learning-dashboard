import { NextResponse } from "next/server";
import { scryptSync, randomBytes, timingSafeEqual } from "crypto";
import { promises as fs } from "fs";
import path from "path";

const FILE = path.join(process.cwd(), "data", "users.json");
type Users = Record<string, { salt: string; hash: string }>;

async function load(): Promise<Users> {
  try { return JSON.parse(await fs.readFile(FILE, "utf8")); } catch { return {}; }
}
async function save(u: Users) {
  await fs.mkdir(path.dirname(FILE), { recursive: true });
  await fs.writeFile(FILE, JSON.stringify(u));
}
const hash = (p: string, salt: string) => scryptSync(p, salt, 32);
const same = (a: Buffer, b: Buffer) => a.length === b.length && timingSafeEqual(a, b);
const fail = (error: string, status = 400) => NextResponse.json({ ok: false, error }, { status });

export async function POST(req: Request) {
  const body = await req.json().catch(() => ({}));
  const action = String(body.action ?? "");
  const username = String(body.username ?? "").trim().toLowerCase();
  const password = String(body.password ?? "");
  const adminU = (process.env.ADMIN_USERNAME ?? "").toLowerCase();
  const adminP = process.env.ADMIN_PASSWORD ?? "";

  if (action === "login") {
    if (adminU && adminP && username === adminU) {
      return same(Buffer.from(password), Buffer.from(adminP))
        ? NextResponse.json({ ok: true, username, role: "admin" })
        : fail("bad", 401);
    }
    const u = (await load())[username];
    if (!u || !same(hash(password, u.salt), Buffer.from(u.hash, "hex"))) return fail("bad", 401);
    return NextResponse.json({ ok: true, username, role: "user" });
  }

  if (action === "signup") {
    if (!/^[a-z0-9_.]{3,20}$/.test(username)) return fail("invalid");
    if (password.length < 6) return fail("short");
    const users = await load();
    if (username === adminU || users[username]) return fail("taken", 409);
    const salt = randomBytes(16).toString("hex");
    users[username] = { salt, hash: hash(password, salt).toString("hex") };
    await save(users);
    return NextResponse.json({ ok: true, username, role: "user" });
  }
  return fail("bad");
}
