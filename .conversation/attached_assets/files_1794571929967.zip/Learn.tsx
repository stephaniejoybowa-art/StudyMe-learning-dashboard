"use client";
import { useEffect, useState } from "react";
import { builtinFor, LevelKey, Mod } from "@/lib/curriculum";
import { LANGS, Lang } from "@/lib/i18n";
import Planner from "@/components/Planner";
import Mascot from "@/components/Mascot";

type Done = Record<string, { score: number; claimed: boolean }>;
type View = "setup" | "course" | "lesson" | "quiz" | "result";

const SUBJECTS = ["Mathematics", "Science", "English", "Computer Science", "History", "Geography"];
const LEVELS: LevelKey[] = ["primary", "secondary", "uni", "adult"];
const levelFromAge = (a: number): LevelKey => (a < 12 ? "primary" : a < 18 ? "secondary" : a < 23 ? "uni" : "adult");

export default function Learn({ accountId, t, lang }: { accountId: string; t: (k: string) => string; lang: Lang }) {
  const key = `studyme:learn:${accountId}`;
  const [age, setAge] = useState("");
  const [level, setLevel] = useState<LevelKey>("secondary");
  const [touched, setTouched] = useState(false);
  const [subject, setSubject] = useState("");
  const [modules, setModules] = useState<Mod[]>([]);
  const [done, setDone] = useState<Done>({});
  const [view, setView] = useState<View>("setup");
  const [idx, setIdx] = useState(0);
  const [answers, setAnswers] = useState<number[]>([]);
  const [passed, setPassed] = useState(false);
  const [score, setScore] = useState(0);
  const [busy, setBusy] = useState("");
  const [error, setError] = useState("");
  const [loaded, setLoaded] = useState(false);
  const [tab, setTab] = useState<"learn" | "plan">("learn");

  useEffect(() => {
    try {
      const raw = localStorage.getItem(key);
      if (raw) {
        const s = JSON.parse(raw);
        setAge(s.age ?? ""); setLevel(s.level ?? "secondary"); setSubject(s.subject ?? "");
        setModules(s.modules ?? []); setDone(s.done ?? {});
        setView((s.modules ?? []).length ? "course" : "setup");
      }
    } catch {}
    setLoaded(true);
  }, [key]);

  useEffect(() => {
    if (!loaded) return;
    try { localStorage.setItem(key, JSON.stringify({ age, level, subject, modules, done })); } catch {}
  }, [age, level, subject, modules, done, loaded, key]);

  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  async function api(body: object): Promise<any> {
    const r = await fetch("/api/learn", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(body) });
    const d = await r.json();
    if (!r.ok || d.error) throw new Error(d.error || "failed");
    return d;
  }

  async function buildCourse() {
    setError(""); setBusy(t("building"));
    const builtin = builtinFor(subject, level);
    try {
      if (builtin && lang === "en") { setModules(builtin); }
      else {
        try {
          const d = await api({ action: "outline", subject, level, age, language: LANGS[lang] });
          setModules(d.modules);
        } catch (e) { if (builtin) setModules(builtin); else throw e; }
      }
      setDone({}); setView("course");
    } catch { setError(t("errAI")); }
    setBusy("");
  }

  async function openModule(i: number) {
    setError(""); setIdx(i);
    const mod = modules[i];
    if (!mod.lesson) {
      setBusy(t("loadingMod"));
      try {
        const d = await api({ action: "module", subject, level, age, title: mod.title, language: LANGS[lang] });
        setModules((ms) => ms.map((x, j) => (j === i ? { ...x, lesson: d.lesson, quiz: d.quiz } : x)));
      } catch { setError(t("errAI")); setBusy(""); return; }
      setBusy("");
    }
    setView("lesson");
  }

  function startQuiz() { setAnswers((modules[idx].quiz ?? []).map(() => -1)); setView("quiz"); }

  function submitQuiz() {
    const mod = modules[idx]; const quiz = mod.quiz ?? [];
    const s = quiz.filter((q, i) => answers[i] === q.answer).length;
    const ok = s >= Math.ceil(quiz.length * 0.6);
    setScore(s); setPassed(ok);
    if (ok) setDone((d) => ({ ...d, [mod.id]: { score: s, claimed: d[mod.id]?.claimed ?? false } }));
    setView("result");
  }

  async function claim() {
    const mod = modules[idx];
    // TODO (Part 5): mint the NFT for this module here with callFunction, then mark it claimed.
    setDone((d) => ({ ...d, [mod.id]: { ...d[mod.id], claimed: true } }));
  }

  const mod = modules[idx];
  const doneCount = modules.filter((x) => done[x.id]).length;
  const pct = modules.length ? Math.round((doneCount / modules.length) * 100) : 0;
  const back = <button type="button" className="sm-ghost sm-gap" onClick={() => setView("course")}>← {t("back")}</button>;

  return (
    <>
    <section className="sm-card sm-wide">
      <div className="sm-tabs" role="tablist">
        <button type="button" className={tab === "learn" ? "sm-active" : ""} onClick={() => setTab("learn")}>📖 {t("tabLearn")}</button>
        <button type="button" className={tab === "plan" ? "sm-active" : ""} onClick={() => setTab("plan")}>🗓 {t("tabPlan")}</button>
      </div>

      {tab === "plan" && <Planner accountId={accountId} t={t} todo={modules.filter((x) => !done[x.id]).map((x) => x.title)} />}

      {tab === "learn" && (<>
      {view === "setup" && (
        <>
          <h3 className="sm-h">{t("learnTitle")}</h3>
          <label className="sm-label">{t("age")}</label>
          <input type="number" min={4} max={100} value={age} placeholder="14"
            onChange={(e) => { setAge(e.target.value); if (!touched && Number(e.target.value) > 0) setLevel(levelFromAge(Number(e.target.value))); }} />
          <label className="sm-label">{t("level")}</label>
          <div className="sm-chips">
            {LEVELS.map((l) => (
              <button key={l} type="button" className={"sm-chip" + (level === l ? " sm-on" : "")} onClick={() => { setLevel(l); setTouched(true); }}>{t("lv_" + l)}</button>
            ))}
          </div>
          <label className="sm-label">{t("subject")}</label>
          <div className="sm-chips">
            {SUBJECTS.map((s) => (
              <button key={s} type="button" className={"sm-chip" + (subject === s ? " sm-on" : "")} onClick={() => setSubject(s)}>{s}</button>
            ))}
          </div>
          <input value={subject} placeholder={t("subjectPh")} onChange={(e) => setSubject(e.target.value)} maxLength={60} />
          <button type="button" className="sm-primary sm-gap" disabled={!!busy || !subject.trim() || !age} onClick={buildCourse}>{busy || t("startCourse")}</button>
        </>
      )}

      {view === "course" && (
        <>
          <h3 className="sm-h">{subject} · {t("lv_" + level)}</h3>
          <div className="sm-progress"><span>{t("modules")}: {doneCount} / {modules.length}</span><span>{pct}%</span></div>
          <div className="sm-bar"><div className="sm-fill" style={{ width: `${pct}%` }} /></div>
          <p className="sm-note">💾 {t("saved")}</p>
          {modules.map((x, i) => (
            <div key={x.id} className={"sm-mod" + (done[x.id] ? " sm-done" : "")}>
              <span>{i + 1}. {x.title} {done[x.id] ? (done[x.id].claimed ? "🎓" : "✓") : ""}</span>
              <button type="button" disabled={!!busy} onClick={() => openModule(i)}>{busy && idx === i ? "…" : done[x.id] ? t("review") : t("startModule")}</button>
            </div>
          ))}
          {busy && <p className="sm-note">{busy}</p>}
          <button type="button" className="sm-ghost sm-gap" onClick={() => { setModules([]); setDone({}); setView("setup"); }}>{t("changeCourse")}</button>
        </>
      )}

      {view === "lesson" && mod && (
        <div className="sm-lesson">
          <h3 className="sm-h">{mod.title}</h3>
          {(mod.lesson ?? "").split(/\n\n+/).map((p, i) => <p key={i}>{p}</p>)}
          <button type="button" className="sm-primary" onClick={startQuiz}>{t("takeQuiz")}</button>
          {back}
        </div>
      )}

      {view === "quiz" && mod && (
        <>
          <h3 className="sm-h">{t("quiz")}: {mod.title}</h3>
          {(mod.quiz ?? []).map((q, qi) => (
            <div key={qi}>
              <div className="sm-q">{qi + 1}. {q.q}</div>
              {q.options.map((o, oi) => (
                <button key={oi} type="button" className={"sm-opt" + (answers[qi] === oi ? " sm-sel" : "")}
                  onClick={() => setAnswers((a) => a.map((v, j) => (j === qi ? oi : v)))}>{o}</button>
              ))}
            </div>
          ))}
          <button type="button" className="sm-primary sm-gap" disabled={answers.includes(-1)} onClick={submitQuiz}>{t("submit")}</button>
        </>
      )}

      {view === "result" && mod && (
        <>
          <div className="sm-big">{score} / {(mod.quiz ?? []).length}</div>
          <p className="sm-claimed">{passed ? t("passed") : t("failed")}</p>
          {passed && !done[mod.id]?.claimed && <button type="button" className="sm-success sm-gap" onClick={claim}>{t("claimModule")}</button>}
          {passed && done[mod.id]?.claimed && (
            <div className="sm-nft">
              <small>{t("nftL")}</small>
              <div className="sm-nft-body">
                <div className="sm-nft-icon">🎓</div>
                <div><b>{t("badge")}</b><div>{mod.title}</div></div>
              </div>
            </div>
          )}
          {!passed && <button type="button" className="sm-primary sm-gap" onClick={() => setView("lesson")}>{t("retry")}</button>}
          {back}
        </>
      )}

      </>)}

      {error && <div className="sm-msg error">{error}</div>}
    </section>
      <Mascot t={t} language={LANGS[lang]} ctx={{ subject, level, age, title: view !== "setup" && view !== "course" ? mod?.title : undefined, lesson: view !== "setup" && view !== "course" ? mod?.lesson : undefined }} />
    </>
  );
}
