"use client";
import { useEffect, useState } from "react";

type Item = { id: string; title: string; date: string; time: string; done: boolean; notified?: boolean };
const pad = (n: number) => String(n).padStart(2, "0");
const ymd = (d: Date) => `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`;
const stamp = (d: Date) => `${d.getFullYear()}${pad(d.getMonth() + 1)}${pad(d.getDate())}T${pad(d.getHours())}${pad(d.getMinutes())}00`;
const when = (i: Item) => new Date(`${i.date}T${i.time}`);

export default function Planner({ accountId, t, todo }: { accountId: string; t: (k: string) => string; todo: string[] }) {
  const key = `studyme:plan:${accountId}`;
  const [items, setItems] = useState<Item[]>([]);
  const [loaded, setLoaded] = useState(false);
  const [title, setTitle] = useState("");
  const [date, setDate] = useState(ymd(new Date()));
  const [time, setTime] = useState("17:00");
  const [remind, setRemind] = useState(false);

  useEffect(() => {
    try { const r = localStorage.getItem(key); if (r) setItems(JSON.parse(r)); } catch {}
    setLoaded(true);
  }, [key]);
  useEffect(() => {
    if (!loaded) return;
    try { localStorage.setItem(key, JSON.stringify(items)); } catch {}
  }, [items, loaded, key]);

  // reminders: work while the app is open
  useEffect(() => {
    if (!remind) return;
    const id = setInterval(() => {
      const now = Date.now();
      setItems((list) => list.map((i) => {
        const at = when(i).getTime();
        if (!i.done && !i.notified && at <= now && now - at < 10 * 60 * 1000) {
          try { new Notification("📚 StudyMe", { body: i.title }); } catch {}
          return { ...i, notified: true };
        }
        return i;
      }));
    }, 30000);
    return () => clearInterval(id);
  }, [remind]);

  function add(tt: string, d: string, tm: string) {
    setItems((l) => [...l, { id: `${Date.now()}-${Math.random().toString(36).slice(2, 6)}`, title: tt, date: d, time: tm, done: false }]);
  }
  function autoPlan() {
    const have = new Set(items.filter((i) => !i.done).map((i) => i.title));
    const fresh = todo.filter((x) => !have.has(x));
    fresh.forEach((name, n) => {
      const d = new Date(); d.setDate(d.getDate() + 1 + n);
      add(name, ymd(d), time);
    });
  }
  async function enableRemind() {
    if (typeof Notification === "undefined") return;
    const p = await Notification.requestPermission();
    setRemind(p === "granted");
  }
  function ics(i: Item) {
    const s = when(i), e = new Date(s.getTime() + 3600000);
    const body = ["BEGIN:VCALENDAR", "VERSION:2.0", "PRODID:-//StudyMe//EN", "BEGIN:VEVENT", `UID:${i.id}@studyme`, `DTSTAMP:${stamp(new Date())}`, `DTSTART:${stamp(s)}`, `DTEND:${stamp(e)}`, `SUMMARY:${i.title.replace(/[\n,;]/g, " ")}`, "END:VEVENT", "END:VCALENDAR"].join("\r\n");
    const a = document.createElement("a");
    a.href = URL.createObjectURL(new Blob([body], { type: "text/calendar" }));
    a.download = "studyme.ics"; a.click();
  }

  const sorted = [...items].sort((a, b) => (a.date + a.time).localeCompare(b.date + b.time));
  const today = ymd(new Date());

  return (
    <div>
      <h3 className="sm-h">🗓 {t("planTitle")}</h3>
      <input value={title} placeholder={t("planWhat")} maxLength={80} onChange={(e) => setTitle(e.target.value)} />
      <div className="sm-row">
        <input type="date" value={date} onChange={(e) => setDate(e.target.value)} />
        <input type="time" value={time} onChange={(e) => setTime(e.target.value)} />
      </div>
      <button type="button" className="sm-primary sm-gap" disabled={!title.trim() || !date} onClick={() => { add(title.trim(), date, time); setTitle(""); }}>{t("planAdd")}</button>
      <div className="sm-row">
        <button type="button" className="sm-ghost sm-gap" disabled={!todo.length} onClick={autoPlan}>✨ {t("planAuto")}</button>
        <button type="button" className="sm-ghost sm-gap" onClick={enableRemind} disabled={remind}>🔔 {remind ? t("remindOn") : t("remind")}</button>
      </div>

      {sorted.length === 0 && <p className="sm-note">{t("planEmpty")}</p>}
      {sorted.map((i) => {
        const late = !i.done && i.date < today;
        return (
          <div key={i.id} className={"sm-mod" + (i.done ? " sm-done" : "")}>
            <label className="sm-plan-l">
              <input type="checkbox" checked={i.done} onChange={() => setItems((l) => l.map((x) => (x.id === i.id ? { ...x, done: !x.done } : x)))} />
              <span>
                <b style={{ textDecoration: i.done ? "line-through" : "none" }}>{i.title}</b><br />
                <small>{i.date} · {i.time} {i.date === today && !i.done ? `· ${t("planToday")}` : ""} {late ? `· ⚠ ${t("planOverdue")}` : ""}</small>
              </span>
            </label>
            <span className="sm-plan-r">
              <button type="button" onClick={() => ics(i)}>{t("ics")}</button>
              <button type="button" aria-label="Delete" onClick={() => setItems((l) => l.filter((x) => x.id !== i.id))}>✕</button>
            </span>
          </div>
        );
      })}
    </div>
  );
}
