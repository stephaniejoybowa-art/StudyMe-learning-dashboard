import { NextResponse } from "next/server";

// NEAR AI Cloud is OpenAI-compatible. Key goes in .env.local as NEARAI_API_KEY.
const BASE = "https://cloud-api.near.ai/v1";
const LEVELS: Record<string, string> = { primary: "primary school", secondary: "secondary school", uni: "college/university", adult: "adult beginner" };

async function ask(prompt: string) {
  const key = process.env.NEARAI_API_KEY;
  if (!key) throw new Error("NEARAI_API_KEY is not set");
  const r = await fetch(`${BASE}/chat/completions`, {
    method: "POST",
    headers: { "Content-Type": "application/json", Authorization: `Bearer ${key}` },
    body: JSON.stringify({
      model: process.env.NEARAI_MODEL || "deepseek-ai/DeepSeek-V3.1", // check cloud-api.near.ai/v1/model/list
      temperature: 0.4,
      max_tokens: 1800,
      messages: [
        { role: "system", content: "You are a friendly, accurate teacher. Reply with ONLY valid JSON, no markdown fences." },
        { role: "user", content: prompt },
      ],
    }),
    signal: AbortSignal.timeout(60000),
  });
  if (!r.ok) throw new Error(`AI error ${r.status}`);
  const d = await r.json();
  const txt: string = d.choices?.[0]?.message?.content ?? "";
  const m = txt.match(/\{[\s\S]*\}/);
  if (!m) throw new Error("AI did not return JSON");
  return JSON.parse(m[0]);
}

export async function POST(req: Request) {
  try {
    const b = await req.json();
    const subject = String(b.subject ?? "").slice(0, 60);
    const title = String(b.title ?? "").slice(0, 80);
    const language = String(b.language ?? "English").slice(0, 20);
    const level = LEVELS[String(b.level)] ?? "secondary school";
    const age = Math.min(100, Math.max(4, Number(b.age) || 14));
    const who = `a ${age}-year-old learner at ${level} level`;

    if (b.action === "outline") {
      const d = await ask(`Design a short course on "${subject}" for ${who}. Write in ${language}. Return JSON: {"modules":[{"title":"..."}]} with exactly 4 modules ordered from basics to harder.`);
      const mods = (d.modules ?? []).slice(0, 6).map((x: { title?: string }, i: number) => ({ id: `m${i + 1}`, title: String(x.title ?? `Module ${i + 1}`) }));
      if (mods.length < 2) throw new Error("bad outline");
      return NextResponse.json({ modules: mods });
    }

    if (b.action === "module") {
      const d = await ask(`Teach the module "${title}" from the course "${subject}" to ${who}. Write in ${language}. Return JSON: {"lesson":"150-220 words, short paragraphs separated by \\n\\n, with one simple example","quiz":[{"q":"...","options":["...","...","...","..."],"answer":0}]} with exactly 3 multiple-choice questions, "answer" being the index (0-3) of the correct option, answers spread across different positions.`);
      const quiz = (d.quiz ?? []).filter((x: { q?: string; options?: unknown[]; answer?: number }) => x.q && Array.isArray(x.options) && x.options.length >= 2 && Number.isInteger(x.answer) && (x.answer as number) < x.options.length);
      if (!d.lesson || quiz.length < 2) throw new Error("bad module");
      return NextResponse.json({ lesson: String(d.lesson), quiz });
    }
    return NextResponse.json({ error: "bad action" }, { status: 400 });
  } catch (e) {
    return NextResponse.json({ error: e instanceof Error ? e.message : "failed" }, { status: 500 });
  }
}
