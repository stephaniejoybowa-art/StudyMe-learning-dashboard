import { NextResponse } from "next/server";

const BASE = "https://cloud-api.near.ai/v1"; // NEAR AI Cloud, OpenAI-compatible
const LEVELS: Record<string, string> = { primary: "primary school", secondary: "secondary school", uni: "college/university", adult: "adult beginner" };

export async function POST(req: Request) {
  try {
    const key = process.env.NEARAI_API_KEY;
    if (!key) return NextResponse.json({ error: "NEARAI_API_KEY is not set" }, { status: 500 });
    const b = await req.json();
    const subject = String(b.subject ?? "").slice(0, 60);
    const level = LEVELS[String(b.level)] ?? "secondary school";
    const age = Math.min(100, Math.max(4, Number(b.age) || 14));
    const language = String(b.language ?? "English").slice(0, 20);
    const title = String(b.title ?? "").slice(0, 80);
    const lesson = String(b.lesson ?? "").slice(0, 2500);
    const messages = (Array.isArray(b.messages) ? b.messages : []).slice(-8).map((m: { role?: string; content?: string }) => ({
      role: m.role === "assistant" ? "assistant" : "user",
      content: String(m.content ?? "").slice(0, 600),
    }));

    const system = [
      "You are Quill, a warm, encouraging study buddy shaped like a little feather quill.",
      `You help a ${age}-year-old learner at ${level} level who is studying ${subject}.`,
      title ? `They are on the module "${title}".` : "",
      lesson ? `The lesson text is:\n${lesson}` : "",
      `Always answer in ${language}. Use simple words and keep replies under 120 words.`,
      "Guide the learner to understand instead of just giving homework answers. Never reveal quiz answers directly; give hints. End with one short follow-up question.",
    ].filter(Boolean).join("\n");

    const r = await fetch(`${BASE}/chat/completions`, {
      method: "POST",
      headers: { "Content-Type": "application/json", Authorization: `Bearer ${key}` },
      body: JSON.stringify({ model: process.env.NEARAI_MODEL || "deepseek-ai/DeepSeek-V3.1", temperature: 0.6, max_tokens: 400, messages: [{ role: "system", content: system }, ...messages] }),
      signal: AbortSignal.timeout(45000),
    });
    if (!r.ok) throw new Error(`AI error ${r.status}`);
    const d = await r.json();
    const reply: string = d.choices?.[0]?.message?.content ?? "";
    if (!reply) throw new Error("empty reply");
    return NextResponse.json({ reply: reply.trim() });
  } catch (e) {
    return NextResponse.json({ error: e instanceof Error ? e.message : "failed" }, { status: 500 });
  }
}
