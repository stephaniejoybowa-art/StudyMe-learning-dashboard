"use client";
import { useEffect, useRef, useState } from "react";
import Image from "next/image";

type Msg = { role: "user" | "assistant"; content: string };
type Ctx = { subject: string; level: string; age: string; title?: string; lesson?: string };

export default function Mascot({ t, language, ctx }: { t: (k: string) => string; language: string; ctx: Ctx }) {
  const [open, setOpen] = useState(false);
  const [msgs, setMsgs] = useState<Msg[]>([]);
  const [text, setText] = useState("");
  const [busy, setBusy] = useState(false);
  const end = useRef<HTMLDivElement>(null);

  useEffect(() => { end.current?.scrollIntoView({ behavior: "smooth" }); }, [msgs, open, busy]);

  async function send(q: string) {
    const content = q.trim();
    if (!content || busy) return;
    const next: Msg[] = [...msgs, { role: "user", content }];
    setMsgs(next); setText(""); setBusy(true);
    try {
      const r = await fetch("/api/tutor", {
        method: "POST", headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ messages: next.slice(-8), language, ...ctx }),
      });
      const d = await r.json();
      if (!r.ok || d.error) throw new Error(d.error || "failed");
      setMsgs([...next, { role: "assistant", content: d.reply }]);
    } catch {
      setMsgs([...next, { role: "assistant", content: t("mascotErr") }]);
    }
    setBusy(false);
  }

  return (
    <>
      {open && (
        <div className="sm-chat" role="dialog" aria-label={t("mascotName")}>
          <div className="sm-chat-head">
            <span className="sm-logo"><Image src="/logo.png" alt="" width={26} height={26} /></span>
            <b>{t("mascotName")}</b>
            <button type="button" onClick={() => setOpen(false)} aria-label="Close">✕</button>
          </div>
          <div className="sm-chat-body">
            <div className="sm-bubble bot">{t("mascotHi")}</div>
            {msgs.length === 0 && (
              <div className="sm-chips">
                {["c1", "c2", "c3", "c4"].map((k) => <button key={k} type="button" className="sm-chip" onClick={() => send(t(k))}>{t(k)}</button>)}
              </div>
            )}
            {msgs.map((m, i) => <div key={i} className={"sm-bubble " + (m.role === "user" ? "me" : "bot")}>{m.content}</div>)}
            {busy && <div className="sm-bubble bot">{t("mascotThinking")}</div>}
            <div ref={end} />
          </div>
          <div className="sm-chat-in">
            <input value={text} placeholder={t("mascotPh")} onChange={(e) => setText(e.target.value)} onKeyDown={(e) => e.key === "Enter" && send(text)} maxLength={400} />
            <button type="button" className="sm-primary" disabled={busy || !text.trim()} onClick={() => send(text)}>{t("mascotSend")}</button>
          </div>
        </div>
      )}
      <button type="button" className="sm-fab" onClick={() => setOpen((o) => !o)} aria-label={t("mascotName")}>
        <Image src="/logo.png" alt="Quill" width={40} height={40} />
      </button>
    </>
  );
}
