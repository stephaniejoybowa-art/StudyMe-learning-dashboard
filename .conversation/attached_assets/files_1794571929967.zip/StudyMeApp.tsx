"use client";

import { useEffect, useState } from "react";
import Image from "next/image";
import { useNearWallet } from "@/providers/near-provider";

import AuthPanel, { Session } from "@/components/AuthPanel";
import Learn from "@/components/Learn";
import { LANGS, Lang, useLang } from "@/lib/i18n";
import "@/styles/studyme.css";

export default function StudyMeApp() {
  const { signedAccountId, loading, signIn, signOut } = useNearWallet();
  const { lang, change, t } = useLang();
  const [session, setSession] = useState<Session | null>(null);
  const [splash, setSplash] = useState(true);

  // show the logo for a moment when the app opens
  useEffect(() => {
    const id = setTimeout(() => setSplash(false), 2100);
    return () => clearTimeout(id);
  }, []);

  useEffect(() => {
    try {
      const s = localStorage.getItem("studyme:session");
      if (s) setSession(JSON.parse(s));
    } catch {}
  }, []);

  if (splash) {
    return (
      <div className="sm-splash">
        <div className="sm-splash-logo">
          <Image src="/logo.png" alt="StudyMe" width={150} height={150} priority />
        </div>
        <div className="sm-splash-name">StudyMe</div>
        <div className="sm-splash-tag">{t("tagline")}</div>
        <div className="sm-dots"><span /><span /><span /></div>
      </div>
    );
  }

  if (loading) return null;

  const who = signedAccountId ?? session?.name;

  if (!who) {
    return <AuthPanel onWalletLogin={() => void signIn()} onChange={setSession} />;
  }

  function logout() {
    if (signedAccountId) void signOut();
    try { localStorage.removeItem("studyme:session"); } catch {}
    setSession(null);
  }

  return (
    <div>
      <div className="sm-top sm-wide">
        <span className="sm-top-left">
          <Image src="/logo.png" alt="StudyMe logo" width={24} height={24} />
          <b>{who}</b> {session?.role === "admin" ? "👑" : ""}
        </span>
        <span className="sm-top-right">
          <select value={lang} onChange={(e) => change(e.target.value as Lang)} aria-label={t("lang")}>
            {Object.entries(LANGS).map(([k, v]) => <option key={k} value={k}>{v}</option>)}
          </select>
          <button type="button" onClick={logout}>{t("logout")}</button>
        </span>
      </div>
      <Learn accountId={who} t={t} lang={lang} />
    </div>
  );
}
