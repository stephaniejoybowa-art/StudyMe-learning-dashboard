"use client";
import { useEffect, useState } from "react";
import Image from "next/image";
import { LANGS, Lang, useLang } from "@/lib/i18n";

export type Session = { name: string; role: "admin" | "user" | "demo" };
type Props = { onWalletLogin?: () => void; onChange?: (s: Session | null) => void };
type Note = { text: string; kind: "" | "error" | "ok" } | null;

export default function AuthPanel({ onWalletLogin, onChange }: Props) {
  const { lang, change, t } = useLang();
  const [tab, setTab] = useState<"in" | "up" | "demo">("in");
  const [user, setUser] = useState("");
  const [pass, setPass] = useState("");
  const [show, setShow] = useState(false);
  const [busy, setBusy] = useState(false);
  const [note, setNote] = useState<Note>(null);

  useEffect(() => { setNote(null); }, [tab]);

  function enter(s: Session) {
    try { localStorage.setItem("studyme:session", JSON.stringify(s)); } catch {}
    onChange?.(s);
  }

  async function submit(action: "login" | "signup") {
    setNote(null); setBusy(true);
    try {
      const r = await fetch("/api/auth", {
        method: "POST", headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ action, username: user, password: pass }),
      });
      const d = await r.json();
      if (d.ok) { setPass(""); enter({ name: d.username, role: d.role }); }
      else setNote({ text: t(d.error ?? "bad"), kind: "error" });
    } catch { setNote({ text: t("bad"), kind: "error" }); }
    setBusy(false);
  }

  return (
    <section className="sm-card">
      <div className="sm-header">
        <div className="sm-brand">
          <span className="sm-logo"><Image src="/logo.png" alt="StudyMe logo" width={34} height={34} /></span>
          <div>
            <div className="sm-name">StudyMe</div>
            <div className="sm-tag">{t("tagline")}</div>
          </div>
        </div>
        <select aria-label={t("lang")} value={lang} onChange={(e) => change(e.target.value as Lang)}>
          {Object.entries(LANGS).map(([k, v]) => <option key={k} value={k}>{v}</option>)}
        </select>
      </div>

      <button type="button" className="sm-primary" onClick={onWalletLogin}>🔗 {t("wallet")}</button>

      <div className="sm-tabs" role="tablist">
        <button type="button" className={tab === "in" ? "sm-active" : ""} onClick={() => setTab("in")}>{t("signin")}</button>
        <button type="button" className={tab === "up" ? "sm-active" : ""} onClick={() => setTab("up")}>{t("create")}</button>
        <button type="button" className={tab === "demo" ? "sm-active" : ""} onClick={() => setTab("demo")}>{t("demo")}</button>
      </div>

      {tab !== "demo" ? (
        <div>
          <input placeholder={t("user")} value={user} onChange={(e) => setUser(e.target.value)} autoComplete="username" spellCheck={false} />
          <div className="sm-pass">
            <input type={show ? "text" : "password"} placeholder={t("pass")} value={pass} onChange={(e) => setPass(e.target.value)} autoComplete={tab === "in" ? "current-password" : "new-password"} />
            <button type="button" className="sm-eye" aria-label={show ? "Hide password" : "Show password"} onClick={() => setShow((v) => !v)}>{show ? "🙈" : "👁"}</button>
          </div>
          <button type="button" className="sm-primary sm-mt" disabled={busy} onClick={() => submit(tab === "in" ? "login" : "signup")}>
            {tab === "in" ? t("login") : t("signupBtn")}
          </button>
          {tab === "up" && (
            <div className="sm-social">
              <button type="button" className="sm-ghost" onClick={() => setNote({ text: t("soon"), kind: "" })}>Google</button>
              <button type="button" className="sm-ghost" onClick={() => setNote({ text: t("soon"), kind: "" })}>📱</button>
            </div>
          )}
        </div>
      ) : (
        <div>
          <p className="sm-note">{t("demoNote")}</p>
          <button type="button" className="sm-primary sm-mt" onClick={() => enter({ name: "demo student", role: "demo" })}>{t("tryDemo")}</button>
        </div>
      )}

      {note && <div className={`sm-msg ${note.kind}`}>{note.text}</div>}
    </section>
  );
}
